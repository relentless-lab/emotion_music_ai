import { defineStore } from "pinia";
import { fetchWorks, createWork, updateWork, deleteWork } from "@/services/workApi";
import { useAuthStore } from "./auth";

export const useWorksStore = defineStore("works", {
  state: () => ({
    list: [],
    loading: false,
    error: ""
  }),
  actions: {
    async loadWorks() {
      const auth = useAuthStore();
      this.loading = true;
      this.error = "";
      try {
        const data = await fetchWorks({ userId: auth.user?.id });
        this.list = data || [];
      } catch (err) {
        this.error = err?.message || "加载失败";
        throw err;
      } finally {
        this.loading = false;
      }
    },
    async addWork(payload) {
      const item = await createWork(payload);
      this.list.unshift(item);
    },
    async editWork(id, payload) {
      const updated = await updateWork(id, payload);
      this.list = this.list.map(w => (w.id === id ? updated : w));
    },
    async removeWork(id) {
      await deleteWork(id);
      this.list = this.list.filter(w => w.id !== id);
    }
  }
});
