<template>
  <div class="emotion-page">
    <div class="gradient"></div>

    <!-- 隐藏的音频元素 -->
    <audio
      ref="audioPlayer"
      :src="fileUrl"
      @timeupdate="onTimeUpdate"
      @loadedmetadata="onLoadedMetadata"
      @ended="onEnded"
      style="display: none"
    ></audio>

    <div class="grid">
      <section class="left-col">
        <div class="card player-card">
          <div class="card-top">
            <div>
              <p class="eyebrow">音乐播放器</p>
              <h2>{{ file ? file.name : '请选择音频文件' }}</h2>
            </div>
            <button class="round-btn" @click="togglePlay" :disabled="!fileUrl">
              {{ isPlaying ? '暂停' : '播放' }}
            </button>
          </div>

          <div class="time-row">
            <span>{{ formatTime(currentTime) }}</span>
            <span>{{ formatTime(duration) }}</span>
          </div>

          <div class="wave-wrap">
            <div class="wave"></div>
            <div class="wave-mask"></div>
          </div>

          <div class="micro-bars">
            <span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span
            ><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span
            ><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span
            ><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span>
          </div>

          <div class="freq-row">
            <span>低频</span>
            <span>中频</span>
            <span>高频</span>
          </div>
        </div>

        <div
          class="card upload-card"
          @dragover.prevent
          @drop="handleDrop"
        >
          <input
            type="file"
            ref="fileInput"
            style="display: none"
            accept="audio/*"
            @change="handleFileChange"
          />
          <div class="upload-header">
            <div class="cloud">&#9729;</div>
            <div>
              <p class="eyebrow">上传音乐文件</p>
              <p class="hint">{{ file ? '已选择: ' + file.name : '点击或拖拽文件到此上传' }}</p>
              <p class="hint small">支持 MP3、WAV、FLAC 格式，最大 50MB</p>
            </div>
          </div>

          <div class="upload-actions">
            <button class="pill primary" @click="triggerFileSelect">选择文件</button>
            <button
              class="pill ghost"
              @click="handleAnalyze"
              :disabled="!file || isAnalyzing"
            >
              {{ isAnalyzing ? '分析中...' : '情绪分析' }}
            </button>
          </div>
        </div>
      </section>

      <section class="right-col">
        <div class="chart-stack">
          <div class="chart-top">
            <div class="card pie-card">
              <div class="card-title">情绪分布饼图</div>
              <div class="pie-body">
                <div class="pie" :style="pieStyle"></div>
                <div class="legend">
                  <div class="legend-item"><span class="chip joy"></span> 兴奋</div>
                  <div class="legend-item"><span class="chip calm"></span> 轻松</div>
                  <div class="legend-item"><span class="chip rest"></span> 休闲</div>
                  <div class="legend-item"><span class="chip relaxed"></span> 悠闲</div>
                  <div class="legend-item"><span class="chip neutral"></span> 平静</div>
                </div>
              </div>
            </div>

            <div class="card quadrant-card">
              <div class="card-title">情绪四象限分布</div>
              <div class="quadrant">
                <div class="axis-label top-left">愤怒 / 厌恶</div>
                <div class="axis-label top-right">兴奋 / 快乐</div>
                <div class="axis-label bottom-left">悲伤 / 怀旧</div>
                <div class="axis-label bottom-right">平静 / 安宁</div>
                <div class="dot" :style="dotPosition"></div>
              </div>
              <div class="quad-meta" v-if="analysisResult">
                <span>愉悦度 {{ analysisResult.quadrant.valence }}%</span>
                <span>脉动率 {{ analysisResult.quadrant.arousal }}%</span>
              </div>
              <div class="quad-meta" v-else>
                <span>待分析</span>
              </div>
            </div>
          </div>

          <div class="card line-card">
            <div class="card-title">情绪波形图</div>
            <div class="line-legend">
              <span class="chip joy"></span> 喜悦
              <span class="chip calm"></span> 轻松
              <span class="chip rest"></span> 休闲
              <span class="chip relaxed"></span> 悠闲
              <span class="chip neutral"></span> 平静
            </div>
            <div class="line-chart">
              <svg viewBox="0 0 1200 280" preserveAspectRatio="xMidYMid slice">
                <defs>
                  <linearGradient id="waveFill" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stop-color="#4fd1ff" stop-opacity="0.48" />
                    <stop offset="100%" stop-color="#0a2c4a" stop-opacity="0.12" />
                  </linearGradient>
                  <linearGradient id="waveStroke" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stop-color="#80d8ff" />
                    <stop offset="50%" stop-color="#7c8bff" />
                    <stop offset="100%" stop-color="#f7b267" />
                  </linearGradient>
                  <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="6" result="blur" />
                    <feMerge>
                      <feMergeNode in="blur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                </defs>

                <g class="grid">
                  <path d="M0 60 H1200" />
                  <path d="M0 110 H1200" />
                  <path d="M0 160 H1200" />
                  <path d="M0 210 H1200" />
                  <path d="M150 0 V280" />
                  <path d="M300 0 V280" />
                  <path d="M450 0 V280" />
                  <path d="M600 0 V280" />
                  <path d="M750 0 V280" />
                  <path d="M900 0 V280" />
                  <path d="M1050 0 V280" />
                  <path d="M1200 0 V280" />
                </g>

                <path
                  class="area"
                  d="M0 190 C130 175, 260 178, 390 182 C520 186, 650 204, 780 180 C910 150, 1040 160, 1120 120 C1160 100, 1200 85, 1200 85 L1200 280 L0 280 Z"
                  fill="url(#waveFill)"
                  filter="url(#glow)"
                />

                <path
                  class="stroke"
                  d="M0 190 C120 175, 240 178, 360 182 C520 188, 640 196, 760 172 C880 145, 1020 168, 1100 130 C1160 100, 1180 70, 1200 50"
                  fill="none"
                  stroke="url(#waveStroke)"
                  stroke-width="4.5"
                  stroke-linecap="round"
                  filter="url(#glow)"
                />

                <g class="points">
                  <circle cx="120" cy="182" r="6" />
                  <circle cx="260" cy="180" r="6" />
                  <circle cx="420" cy="186" r="6" />
                  <circle cx="560" cy="195" r="6" />
                  <circle cx="700" cy="178" r="6" />
                  <circle cx="860" cy="150" r="6" />
                  <circle cx="1020" cy="165" r="6" />
                  <circle cx="1120" cy="128" r="6" />
                  <circle cx="1185" cy="62" r="6" />
                </g>
              </svg>
            </div>
            <div class="meta-row">
              <span>当前情绪强度: <strong>85%</strong></span>
              <span>情绪变化程度: <strong>中等</strong></span>
            </div>
          </div>
        </div>

        <div class="card report-card">
          <div class="report-header">
            <span class="brain">🧠</span>
            <div>
              <p class="eyebrow">AI 情绪分析报告</p>
              <p class="hint">剖析情感反馈</p>
            </div>
          </div>
          <div class="report-body">
            {{ analysisResult ? analysisResult.report : '请上传音频并点击分析以获取报告。' }}
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onUnmounted } from "vue";
import { analyzeAudio } from "@/services/emotionApi";

// 状态
const file = ref(null);
const fileUrl = ref("");
const isAnalyzing = ref(false);
const analysisResult = ref(null);
const audioPlayer = ref(null);
const isPlaying = ref(false);
const currentTime = ref(0);
const duration = ref(0);

// 文件选择引用
const fileInput = ref(null);

// 格式化时间
const formatTime = (time) => {
  if (!time) return "00:00";
  const m = Math.floor(time / 60)
    .toString()
    .padStart(2, "0");
  const s = Math.floor(time % 60)
    .toString()
    .padStart(2, "0");
  return `${m}:${s}`;
};

// 触发文件选择
const triggerFileSelect = () => {
  fileInput.value?.click();
};

// 处理文件变更
const handleFileChange = (event) => {
  const selected = event.target.files?.[0];
  if (selected) {
    setFile(selected);
  }
};

// 处理拖拽
const handleDrop = (event) => {
  event.preventDefault();
  const dropped = event.dataTransfer?.files?.[0];
  if (dropped) {
    setFile(dropped);
  }
};

const setFile = (f) => {
  // 简单的校验
  if (!f.type.startsWith("audio/")) {
    alert("请上传音频文件");
    return;
  }
  file.value = f;
  // 生成预览 URL
  if (fileUrl.value) URL.revokeObjectURL(fileUrl.value);
  fileUrl.value = URL.createObjectURL(f);
  // 重置状态
  analysisResult.value = null;
  isPlaying.value = false;
  currentTime.value = 0;
  duration.value = 0;
};

// 开始分析
const handleAnalyze = async () => {
  if (!file.value) return;
  
  isAnalyzing.value = true;
  try {
    const result = await analyzeAudio(file.value);
    analysisResult.value = result;
  } catch (error) {
    console.error(error);
    alert(error.message || "分析失败");
  } finally {
    isAnalyzing.value = false;
  }
};

// 播放控制
const togglePlay = () => {
  if (!audioPlayer.value) return;
  if (isPlaying.value) {
    audioPlayer.value.pause();
  } else {
    audioPlayer.value.play();
  }
  isPlaying.value = !isPlaying.value;
};

const onTimeUpdate = () => {
  if (audioPlayer.value) {
    currentTime.value = audioPlayer.value.currentTime;
  }
};

const onLoadedMetadata = () => {
  if (audioPlayer.value) {
    duration.value = audioPlayer.value.duration;
  }
};

const onEnded = () => {
  isPlaying.value = false;
};

// 计算属性：动态样式
const pieStyle = computed(() => {
  if (!analysisResult.value) return {};
  const { joy, calm, rest, relaxed, neutral } = analysisResult.value.pieData;
  // 计算累积百分比
  const p1 = joy * 100;
  const p2 = p1 + calm * 100;
  const p3 = p2 + rest * 100;
  const p4 = p3 + relaxed * 100;
  
  return {
    background: `conic-gradient(
      #ffb347 0 ${p1}%,
      #3dc3ff ${p1}% ${p2}%,
      #ff7b00 ${p2}% ${p3}%,
      #ff3ca0 ${p3}% ${p4}%,
      #8ef1ba ${p4}% 100%
    )`
  };
});

const dotPosition = computed(() => {
  if (!analysisResult.value) return { display: 'none' };
  const { x, y } = analysisResult.value.quadrant;
  // 将 -1~1 映射到 0%~100%
  // x: -1 => 0%, 1 => 100%
  // y: 1 => 0% (top), -1 => 100% (bottom)
  const left = (x + 1) * 50;
  const top = (1 - y) * 50;
  return {
    left: `${left}%`,
    top: `${top}%`,
    display: 'block'
  };
});

onUnmounted(() => {
  if (fileUrl.value) URL.revokeObjectURL(fileUrl.value);
});
</script>

<style scoped>
:global(body) {
  font-family: "Plus Jakarta Sans", "Segoe UI", "Microsoft YaHei", sans-serif;
}

.emotion-page {
  position: relative;
  min-height: calc(100vh - 120px);
  padding: 8px 4px 16px;
  color: #e9ecff;
}

.gradient {
  position: absolute;
  inset: -120px -120px auto -120px;
  background:
    radial-gradient(circle at 10% 15%, rgba(67, 210, 255, 0.35), transparent 35%),
    radial-gradient(circle at 65% 5%, rgba(255, 95, 109, 0.35), transparent 35%),
    radial-gradient(circle at 80% 70%, rgba(87, 206, 143, 0.35), transparent 38%),
    linear-gradient(135deg, #093b63 0%, #081338 50%, #05091f 100%);
  filter: blur(6px);
  z-index: 0;
}

.grid {
  position: relative;
  display: grid;
  grid-template-columns: 360px 1fr;
  gap: 16px;
  z-index: 1;
}

.card {
  background: linear-gradient(145deg, rgba(12, 19, 46, 0.9), rgba(6, 12, 32, 0.88));
  border: 1px solid rgba(110, 136, 255, 0.25);
  border-radius: 16px;
  box-shadow: 0 22px 50px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(6px);
}

.left-col {
  display: grid;
  grid-template-rows: 1fr auto;
  gap: 16px;
  min-height: 0;
}

.player-card {
  padding: 16px 16px 14px;
  display: grid;
  grid-template-rows: auto auto auto 1fr auto;
  gap: 12px;
}

.card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.card-top h2 {
  margin: 2px 0 0;
  font-size: 16px;
  letter-spacing: 0.02em;
}

.eyebrow {
  margin: 0;
  font-size: 12px;
  letter-spacing: 0.06em;
  color: rgba(233, 236, 255, 0.8);
}

.round-btn {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: none;
  background: linear-gradient(135deg, #7dd3fc, #c084fc);
  color: #04112a;
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 10px 30px rgba(125, 211, 252, 0.35);
}

.time-row {
  display: flex;
  justify-content: space-between;
  color: rgba(233, 236, 255, 0.65);
  font-size: 12px;
}

.wave-wrap {
  position: relative;
  height: 180px;
  border-radius: 14px;
  overflow: hidden;
  background: linear-gradient(180deg, rgba(27, 40, 88, 0.8), rgba(12, 16, 38, 0.95));
  border: 1px solid rgba(124, 143, 255, 0.25);
}

.wave {
  position: absolute;
  inset: 0;
  background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 800 260'%3E%3Cpath d='M0 160 C50 110 100 210 160 160 C230 95 310 210 380 150 C450 90 510 200 600 140 C690 80 730 210 800 170' fill='none' stroke='%23c2a6ff' stroke-width='12' stroke-linecap='round'/%3E%3C/svg%3E")
    center/cover no-repeat;
  opacity: 0.82;
}

.wave-mask {
  position: absolute;
  inset: 0;
  background: linear-gradient(90deg, rgba(5, 8, 26, 0.35) 40%, transparent 60%), linear-gradient(0deg, rgba(5, 8, 26, 0.3), rgba(5, 8, 26, 0.1));
}

.micro-bars {
  display: grid;
  grid-template-columns: repeat(32, 1fr);
  gap: 3px;
  align-items: end;
  height: 34px;
  padding: 0 2px;
}

.micro-bars span {
  display: block;
  width: 100%;
  border-radius: 2px;
  background: linear-gradient(180deg, #9ec5ff, #6c8dff);
  height: 50%;
}

.micro-bars span:nth-child(4n) {
  height: 24%;
}

.micro-bars span:nth-child(6n) {
  height: 68%;
}

.micro-bars span:nth-child(5n) {
  height: 38%;
}

.micro-bars span:nth-child(7n) {
  height: 72%;
}

.freq-row {
  display: flex;
  justify-content: space-between;
  color: rgba(233, 236, 255, 0.75);
  font-size: 12px;
  padding: 0 4px 2px;
}

.upload-card {
  padding: 18px 16px;
  border-style: dashed;
  border-color: rgba(119, 133, 255, 0.35);
  border-width: 1px;
  display: grid;
  gap: 14px;
}

.upload-header {
  display: flex;
  gap: 14px;
  align-items: center;
}

.cloud {
  width: 54px;
  height: 54px;
  border-radius: 14px;
  background: linear-gradient(135deg, rgba(124, 143, 255, 0.16), rgba(124, 143, 255, 0.05));
  border: 1px solid rgba(124, 143, 255, 0.25);
  display: grid;
  place-items: center;
  font-size: 22px;
}

.hint {
  margin: 4px 0 0;
  color: rgba(233, 236, 255, 0.8);
  font-size: 13px;
}

.hint.small {
  font-size: 12px;
  color: rgba(233, 236, 255, 0.65);
}

.upload-actions {
  display: flex;
  gap: 10px;
}

.pill {
  flex: 1;
  padding: 12px 0;
  border-radius: 30px;
  font-weight: 700;
  border: none;
  cursor: pointer;
  letter-spacing: 0.01em;
}

.pill.primary {
  background: linear-gradient(135deg, #7dd3fc, #b197ff);
  color: #0a0f1d;
  box-shadow: 0 12px 28px rgba(125, 211, 252, 0.35);
}

.pill.ghost {
  background: rgba(255, 255, 255, 0.08);
  color: #e9ecff;
  border: 1px solid rgba(255, 255, 255, 0.25);
}

.right-col {
  display: grid;
  grid-template-rows: auto auto;
  gap: 16px;
  min-height: 0;
}

.chart-stack {
  display: grid;
  grid-template-rows: auto auto;
  gap: 14px;
}

.chart-top {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
}

.card-title {
  font-weight: 800;
  letter-spacing: 0.01em;
  margin-bottom: 12px;
}

.pie-card {
  padding: 16px;
  background: linear-gradient(135deg, rgba(29, 144, 165, 0.85), rgba(11, 52, 77, 0.9));
  min-height: 360px;
}

.pie-body {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 32px;
  height: 100%;
  padding: 0 12px 12px;
}

.pie {
  width: clamp(220px, 42vw, 320px);
  height: clamp(220px, 42vw, 320px);
  border-radius: 50%;
  background: conic-gradient(#a8d95f 0 38%, #32b8e2 38% 58%, #f7a321 58% 72%, #ff3ca0 72% 82%, #7e55ff 82% 100%);
  box-shadow:
    inset 0 0 0 12px rgba(6, 14, 32, 0.35),
    0 20px 40px rgba(0, 0, 0, 0.25);
  transform: translateY(-14px);
}

.legend {
  display: grid;
  gap: 10px;
  font-size: 14px;
  color: #e8fbff;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 8px;
}

.chip {
  display: inline-block;
  width: 14px;
  height: 8px;
  border-radius: 999px;
}

.joy {
  background: #ffb347;
}

.calm {
  background: #3dc3ff;
}

.rest {
  background: #ff7b00;
}

.relaxed {
  background: #ff3ca0;
}

.neutral {
  background: #8ef1ba;
}

.line-card {
  padding: 16px;
  background: linear-gradient(135deg, rgba(14, 33, 82, 0.85), rgba(7, 18, 50, 0.92));
  display: grid;
  grid-template-rows: auto auto 1fr auto;
  gap: 12px;
}

.line-legend {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  font-size: 13px;
  color: rgba(233, 236, 255, 0.9);
}

.line-chart {
  background:
    radial-gradient(circle at 15% 20%, rgba(88, 136, 255, 0.22), transparent 50%),
    linear-gradient(180deg, rgba(16, 31, 64, 0.9), rgba(6, 17, 42, 0.94));
  border: 1px solid rgba(99, 132, 255, 0.18);
  border-radius: 12px;
  padding: 10px 10px 12px;
  overflow: hidden;
}

.line-chart svg {
  width: 100%;
  height: 240px;
}

.line-chart .grid path {
  stroke: rgba(255, 255, 255, 0.06);
  stroke-width: 1;
}

.line-chart .area {
  opacity: 0.9;
}

.line-chart .stroke {
  stroke-linejoin: round;
}

.line-chart .points circle {
  fill: #ffd166;
  stroke: rgba(10, 17, 34, 0.7);
  stroke-width: 2;
  filter: drop-shadow(0 0 6px rgba(255, 209, 102, 0.5));
}

.meta-row {
  display: flex;
  gap: 20px;
  color: rgba(233, 236, 255, 0.85);
  font-size: 13px;
}

.meta-row strong {
  color: #ffd166;
}

.quadrant-card {
  padding: 16px;
  background: linear-gradient(135deg, rgba(12, 33, 74, 0.9), rgba(7, 25, 60, 0.9));
  display: grid;
  gap: 12px;
}

.quadrant {
  position: relative;
  height: 240px;
  background: radial-gradient(circle at 65% 40%, rgba(255, 184, 79, 0.2), transparent 45%), rgba(8, 18, 40, 0.8);
  border: 1px solid rgba(116, 149, 255, 0.2);
  border-radius: 12px;
  overflow: hidden;
}

.quadrant::before,
.quadrant::after {
  content: "";
  position: absolute;
  background: rgba(255, 255, 255, 0.08);
}

.quadrant::before {
  width: 1px;
  height: 100%;
  left: 50%;
  top: 0;
}

.quadrant::after {
  height: 1px;
  width: 100%;
  top: 50%;
  left: 0;
}

.axis-label {
  position: absolute;
  font-size: 12px;
  color: rgba(233, 236, 255, 0.8);
  padding: 6px 10px;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.top-left {
  left: 14px;
  top: 14px;
}

.top-right {
  right: 14px;
  top: 14px;
}

.bottom-left {
  left: 14px;
  bottom: 14px;
}

.bottom-right {
  right: 14px;
  bottom: 14px;
}

.quadrant .dot {
  position: absolute;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: radial-gradient(circle, #ffd166 35%, #ff9f1c 100%);
  box-shadow: 0 0 0 8px rgba(255, 209, 102, 0.2);
  right: 80px;
  top: 92px;
}

.quad-meta {
  display: flex;
  justify-content: space-between;
  color: rgba(233, 236, 255, 0.82);
  font-size: 13px;
}

.report-card {
  padding: 16px;
  background: linear-gradient(135deg, rgba(23, 117, 137, 0.85), rgba(6, 26, 66, 0.92));
  min-height: 180px;
  display: grid;
  gap: 12px;
}

.report-header {
  display: flex;
  gap: 10px;
  align-items: center;
}

.brain {
  width: 38px;
  height: 38px;
  border-radius: 12px;
  display: grid;
  place-items: center;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 20px;
}

.report-body {
  background: rgba(5, 12, 32, 0.32);
  border-radius: 12px;
  padding: 14px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: rgba(233, 236, 255, 0.9);
  line-height: 1.6;
  min-height: 96px;
}

@media (max-width: 1180px) {
  .grid {
    grid-template-columns: 1fr;
  }

  .left-col {
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  }

  .right-col {
    grid-template-rows: auto auto;
  }

  .chart-top {
    grid-template-columns: 1fr;
  }

  .quad-meta {
    flex-direction: column;
    gap: 6px;
    align-items: flex-start;
  }
}

@media (max-width: 720px) {
  .emotion-page {
    padding: 6px 0 12px;
  }

  .player-card {
    grid-template-rows: auto auto 140px auto auto;
  }

  .micro-bars {
    grid-template-columns: repeat(20, 1fr);
  }

  .upload-actions {
    flex-direction: column;
  }
}
</style>


