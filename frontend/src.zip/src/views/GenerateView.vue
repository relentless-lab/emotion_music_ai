<template>
  <div class="page">
    <section class="panel chat-panel">
      <header class="panel-header">
        <div>
          <p class="eyebrow">音乐生成</p>
          <h2>{{ displayTitle ? `「${displayTitle}」` : "音乐创作对话" }}</h2>
        </div>
        <div class="dialogue-meta">
          <button class="ghost-btn small" type="button" @click="resetDialogue" :disabled="sending">
            新建对话
          </button>
        </div>
      </header>

      <div class="chat-scroll custom-scrollbar">
        <div v-if="messages.length === 0" class="empty-state">
          <p class="muted">开始输入，开启新的对话。</p>
        </div>

        <div v-else class="chat-flow">
          <div v-for="msg in messages" :key="msg.localId" class="chat-step" :class="msg.role">
            <div class="bubble">
              {{ msg.text }}
            </div>
          </div>

          <div v-if="sending" class="status">
            <span class="pulse-dot"></span>
            等待系统回复...
          </div>
          <div v-if="error" class="error-line">{{ error }}</div>
        </div>
      </div>

      <div class="controls-area">
        <div class="mood-row">
          <button
            v-for="preset in presets"
            :key="preset.label"
            class="pill"
            :class="preset.tone"
            type="button"
            @click="applyPreset(preset.text)"
          >
            {{ preset.label }}
          </button>
        </div>

        <div class="input-block">
          <label>描述你的音乐灵感</label>
          <textarea
            v-model="messageInput"
            :disabled="sending"
            @keydown.enter.exact.prevent="sendMessage"
            placeholder="例如：在雨夜街头的慢板爵士，带点复古氛围和萨克斯风..."
          ></textarea>
        </div>

        <div class="cta-row">
          <button class="primary-btn" type="button" :disabled="sending || !messageInput.trim()" @click="sendMessage">
            <span class="sparkle">✨</span>
            {{ sending ? "生成中..." : "发送并生成音乐" }}
          </button>
          <div class="mode-switch">
            <div class="switch-bg model-switch">
              <button class="pill tiny active" type="button" @click="cycleModel">
                {{ selectedModel?.label || "默认模型" }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="panel main-panel">
      <header class="panel-header">
        <h2>生成音乐列表</h2>
        <span class="chip soft">共 {{ generatedTracks.length }} 首</span>
      </header>

      <div v-if="currentTrack" class="playlist-card highlight">
        <div class="thumb-glow"></div>
        <div class="thumb">🎵</div>
        <div class="playlist-info">
          <div class="playlist-title">{{ currentTrack.title }}</div>
          <div class="playlist-meta">
            {{ currentTrack.artist || "AI Composer" }}
            <span v-if="currentTrack.album">· {{ currentTrack.album }}</span>
            <span v-if="currentTrack.mood">· {{ currentTrack.mood }}</span>
          </div>
        </div>
        <div class="track-time">{{ formatDuration(currentTrack.duration) }}</div>
        <button class="ghost-btn icon-only" title="播放" @click="playTrack(generatedTracks.length - 1)">▶</button>
      </div>
      <div v-else class="placeholder-card">等待生成音乐 URL...</div>

      <div v-if="generatedTracks.length" class="track-list tall">
        <div class="list-head">
          <h4>全部生成</h4>
          <span class="muted">点击播放将同步到底部播放栏</span>
        </div>
        <div
          v-for="(track, index) in generatedTracks"
          :key="track.id || index"
          class="track-row mini-card"
        >
          <div class="track-cover">🎵</div>
          <div class="track-info">
            <div class="track-title">{{ track.title }}</div>
            <div class="track-sub">
              <span>{{ track.artist || "AI Composer" }}</span>
              <span v-if="track.mood" class="dot-sep">·</span>
              <span v-if="track.mood">{{ track.mood }}</span>
            </div>
          </div>
          <div class="track-time">{{ formatDuration(track.duration) }}</div>
          <button class="play-icon-btn" title="播放" @click="playTrack(index)">▶</button>
        </div>
      </div>
    </section>

    <section class="panel insights-panel">
      <header class="panel-header">
        <h2>情绪饼图（占位）</h2>
      </header>

      <div class="pie-placeholder">
        <div class="donut-wrap">
          <div class="donut"></div>
          <div class="inner-circle">
            <span class="score">78</span>
            <span class="label">占位</span>
          </div>
        </div>
        <p class="muted">右侧预留饼图区域，后续接入实际数据。</p>
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from "vue";
import { useRoute } from "vue-router";
import { chatWithDialogue, getDialogueDetail } from "@/services/dialogueApi";
import { usePlayerStore } from "@/stores/player";

const route = useRoute();
const messageInput = ref("");
const dialogueId = ref(null);
const messages = ref([]);
const generatedTracks = ref([]);
const lastResponse = ref(null);
const sending = ref(false);
const error = ref("");
const modelIndex = ref(0);

const modelOptions = [
  { label: "默认模型", value: "default" },
  { label: "高质量模型", value: "hq" },
  { label: "极速模型", value: "fast" }
];

const presets = [
  { label: "😊 高兴", tone: "warm", text: "来一首明亮的电子流行，用于生日派对现场。" },
  { label: "😔 伤心", tone: "calm", text: "写一段舒缓的钢琴，表达深夜的忧伤。" },
  { label: "🤩 兴奋", tone: "vivid", text: "创作一段未来感电音，适合开场灯光秀。" },
  { label: "🍃 平静", tone: "calm", text: "需要一首轻柔的氛围音乐，适合工作时背景。" }
];

const player = usePlayerStore();
onMounted(async () => {
  player.initAudio();
  if (route.query.dialogueId) {
    await loadDialogue(route.query.dialogueId);
  }
});

const loadDialogue = async id => {
  try {
    const res = await getDialogueDetail(id);
    if (res && res.data) {
      // 假设返回的是对话历史列表，我们需要根据实际 API 返回结构调整
      // 这里先做一个基本的假设：返回的是包含 messages 数组的对象
      // 如果后端返回的是单次对话记录，可能需要调整处理逻辑
      // 根据之前的 normalizeResponse 逻辑，这里可能需要适配一下

      // 暂时假设返回的是一个完整的对话历史对象
      // 由于接口文档没有明确说明 GET /api/dialogues/{id} 的返回结构
      // 我们先假设它返回的是类似对话历史的列表或者单个对话详情
      
      // 如果返回的是单条记录（类似 chatWithDialogue 的返回），我们可以复用 normalizeResponse
      // 但通常详情接口会返回整个对话的所有消息
      
      // 这里的逻辑可能需要根据实际联调调整。
      // 先做一种比较通用的处理：如果返回的是数组，就当做消息列表处理
      
      const data = res.data;
      dialogueId.value = id;
      
      if (Array.isArray(data.messages)) {
         messages.value = data.messages.map(msg => ({
             localId: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
             role: msg.role || (msg.is_user ? 'user' : 'assistant'), // 适配常见字段
             text: msg.content || msg.message || msg.reply,
             createdAt: msg.created_at || new Date().toISOString()
         }));
      } else if (data.message && data.reply) {
          // 单条记录回显
          const normalized = normalizeResponse(res);
          lastResponse.value = normalized;
          
          if (normalized.userMessage) {
            addMessage("user", normalized.userMessage, {
                createdAt: normalized.createdAt,
                messageId: normalized.messageId
            });
          }
          if (normalized.systemReply) {
             addMessage("assistant", normalized.systemReply, {
                createdAt: normalized.createdAt,
                messageId: normalized.messageId
            });
          }
          if (normalized.track) {
              addTrack(normalized.track, normalized.order, normalized.createdAt);
          }
      }
    }
  } catch (err) {
    console.error("加载对话详情失败:", err);
    error.value = "加载历史对话失败";
  }
};

const selectedModel = computed(() => modelOptions[modelIndex.value] || modelOptions[0]);
const displayTitle = computed(() => lastResponse.value?.title || "");
const currentTrack = computed(() => {
  if (!generatedTracks.value.length) return null;
  return generatedTracks.value[generatedTracks.value.length - 1];
});
const nextOrder = computed(() => {
  const maxOrder = messages.value.reduce((max, item) => Math.max(max, item.order || 0), 0);
  return (maxOrder || 0) + 1;
});

watch(
  generatedTracks,
  list => {
    if (list.length) {
      player.setPlaylist(list, list.length - 1);
    }
  },
  { deep: true }
);

const formatTime = value => {
  if (!value) return "未提供时间";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString("zh-CN", { hour12: false });
};

const formatDuration = seconds => {
  if (!seconds && seconds !== 0) return "--:--";
  const safe = Math.max(0, Math.floor(seconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
};

const applyPreset = text => {
  messageInput.value = text;
};

const cycleModel = () => {
  modelIndex.value = (modelIndex.value + 1) % modelOptions.length;
};

const resetDialogue = () => {
  dialogueId.value = null;
  messages.value = [];
  generatedTracks.value = [];
  lastResponse.value = null;
  error.value = "";
  messageInput.value = "";
  modelIndex.value = 0;
};

const addMessage = (role, text, meta = {}) => {
  const entry = {
    localId: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    role,
    text,
    createdAt: meta.createdAt || new Date().toISOString(),
    messageId: meta.messageId ?? null,
    order: meta.order ?? null
  };
  messages.value.push(entry);
  return entry;
};

const addTrack = (track, order, createdAt) => {
  const normalized = {
    id: track.id || `${Date.now()}`,
    title: track.title || "AI 生成作品",
    artist: track.artist || "AI Composer",
    album: track.album || "",
    cover: track.cover || "",
    url: track.url,
    duration: track.duration || 0,
    mood: track.mood || track.genre || "",
    order: order || null,
    createdAt: createdAt || new Date().toISOString()
  };
  generatedTracks.value = [...generatedTracks.value, normalized];
};

const normalizeResponse = payload => {
  const data =
    payload && typeof payload === "object" && "data" in payload && payload.data ? payload.data : payload || {};

  const pick = keys => {
    for (const key of keys) {
      const val = data?.[key];
      if (val !== undefined && val !== null && val !== "") return val;
    }
    return null;
  };

  const normalizedOrder = Number(pick(["order", "seq", "index", "number"]));
  const musicInfo = data?.music || data?.music_info || data?.musicInfo || data?.track || data?.song || {};
  const musicUrl = pick(["music_url", "musicUrl", "song_url", "songUrl", "url"]) || musicInfo.url;

  const track = musicUrl
    ? {
        id: musicInfo.id || pick(["message_id", "messageId"]) || `${Date.now()}`,
        title: musicInfo.title || musicInfo.name || pick(["title", "dialogue_title", "name"]) || "AI 生成作品",
        artist: musicInfo.artist || musicInfo.author || musicInfo.composer || "AI Composer",
        album: musicInfo.album || musicInfo.collection,
        cover: musicInfo.cover || musicInfo.cover_url || musicInfo.coverUrl,
        url: musicUrl,
        duration: musicInfo.duration || musicInfo.length,
        mood: musicInfo.mood || musicInfo.style,
        genre: musicInfo.genre || musicInfo.tag
      }
    : null;

  return {
    dialogueId: pick(["dialogue_id", "dialogueId", "id"]),
    messageId: pick(["message_id", "messageId"]),
    userMessage: pick(["message", "user_message", "userMessage", "prompt", "question"]),
    systemReply: pick(["reply", "system_reply", "systemReply", "answer", "response", "content"]),
    order: Number.isFinite(normalizedOrder) ? normalizedOrder : null,
    title: pick(["title", "dialogue_title", "name"]),
    createdAt: pick(["created_at", "createdAt", "created", "timestamp", "time"]),
    track
  };
};

const sendMessage = async () => {
  const text = messageInput.value.trim();
  if (!text) {
    error.value = "请先输入要生成的描述";
    return;
  }

  const provisionalOrder = nextOrder.value;
  const now = new Date().toISOString();
  const userEntry = addMessage("user", text, { order: provisionalOrder, createdAt: now });

  sending.value = true;
  error.value = "";

  try {
    const body = { message: text, model: selectedModel.value?.value };
    if (dialogueId.value) body.dialogue_id = dialogueId.value;

    const res = await chatWithDialogue(body);
    const normalized = normalizeResponse(res);

    dialogueId.value = normalized.dialogueId ?? dialogueId.value;
    lastResponse.value = {
      ...normalized,
      systemReply: normalized.systemReply,
      messageId: normalized.messageId
    };

    const orderValue = normalized.order || provisionalOrder;
    userEntry.order = orderValue;
    userEntry.messageId = normalized.messageId;
    userEntry.createdAt = normalized.createdAt || now;
    if (normalized.userMessage) {
      userEntry.text = normalized.userMessage;
    }

    addMessage("assistant", normalized.systemReply || "系统已收到指令，正在处理音乐中", {
      order: orderValue,
      createdAt: normalized.createdAt || now,
      messageId: normalized.messageId
    });

    if (normalized.track) {
      addTrack(normalized.track, orderValue, normalized.createdAt || now);
    }

    messageInput.value = "";
  } catch (err) {
    error.value = err?.message || "生成失败，请稍后重试";
  } finally {
    sending.value = false;
  }
};

const playTrack = index => {
  if (!generatedTracks.value.length) return;
  const normalizedIndex = Math.max(0, Math.min(index, generatedTracks.value.length - 1));
  player.setPlaylist(generatedTracks.value, normalizedIndex);
  player.playTrack(normalizedIndex);
};
</script>

<style scoped>
:global(body) {
  font-family: "Inter", system-ui, -apple-system, "Microsoft YaHei", sans-serif;
}

.page {
  display: grid;
  grid-template-columns: 1.05fr 1.6fr 0.95fr;
  gap: 20px;
  min-height: calc(100vh - 140px);
  padding-bottom: 12px;
  color: #e2e8f0;
}

.panel {
  background: rgba(17, 24, 39, 0.7);
  backdrop-filter: blur(18px);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 18px;
  padding: 22px;
  display: flex;
  flex-direction: column;
  gap: 14px;
  box-shadow:
    0 4px 6px -1px rgba(0, 0, 0, 0.1),
    0 12px 30px rgba(0, 0, 0, 0.28),
    inset 0 0 20px rgba(0, 0, 0, 0.2);
}

.chat-panel {
  max-height: calc(100vh - 140px);
  overflow: hidden;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
}

.panel-header h2 {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
  letter-spacing: 0.02em;
}

.title-inline {
  margin: 4px 0 0;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.7);
}

.eyebrow {
  margin: 0 0 4px;
  font-size: 12px;
  letter-spacing: 0.1em;
  color: rgba(255, 255, 255, 0.6);
  text-transform: uppercase;
}

.dialogue-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.chip {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 999px;
  padding: 6px 10px;
  font-size: 12px;
  font-weight: 700;
}

.chip.soft {
  background: rgba(96, 165, 250, 0.16);
  border-color: rgba(96, 165, 250, 0.3);
}

.ghost-btn {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: #fff;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.ghost-btn:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.18);
}

.ghost-btn:disabled {
  opacity: 0.55;
  cursor: not-allowed;
}

.ghost-btn.small {
  padding: 6px 10px;
  font-weight: 600;
  font-size: 12px;
}

.chat-scroll {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding-right: 6px;
  max-height: calc(100vh - 320px);
}

.custom-scrollbar::-webkit-scrollbar {
  width: 6px;
}

.custom-scrollbar::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 10px;
}

.empty-state {
  background: rgba(255, 255, 255, 0.03);
  border: 1px dashed rgba(148, 163, 184, 0.2);
  border-radius: 14px;
  padding: 12px;
  color: rgba(226, 232, 240, 0.65);
  line-height: 1.5;
  text-align: center;
}

.chat-flow {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 4px;
}

.chat-step {
  display: flex;
  width: fit-content;
  max-width: 85%;
  position: relative;
}

.chat-step.user {
  align-self: flex-end;
}

.chat-step.assistant {
  align-self: flex-start;
}

.bubble {
  position: relative;
  background: rgba(255, 255, 255, 0.04);
  padding: 10px 14px;
  border-radius: 12px;
  color: #e2e8f0;
  font-size: 14px;
  line-height: 1.5;
  word-break: break-word;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.chat-step.user .bubble {
  background: #3b82f6;
  color: #fff;
  border-top-right-radius: 2px;
  margin-right: 6px;
}

.chat-step.user .bubble::after {
  content: "";
  position: absolute;
  top: 0;
  right: -8px;
  width: 0;
  height: 0;
  border-top: 10px solid #3b82f6;
  border-right: 10px solid transparent;
}

.chat-step.assistant .bubble {
  background: #334155;
  color: #e2e8f0;
  border-top-left-radius: 2px;
  margin-left: 6px;
}

.chat-step.assistant .bubble::before {
  content: "";
  position: absolute;
  top: 0;
  left: -8px;
  width: 0;
  height: 0;
  border-top: 10px solid #334155;
  border-left: 10px solid transparent;
}

.dot-sep {
  color: rgba(255, 255, 255, 0.4);
}

.status {
  font-size: 12px;
  color: #fbbf24;
  display: flex;
  align-items: center;
  gap: 6px;
  align-self: flex-start;
  padding-left: 6px;
}

.pulse-dot {
  width: 8px;
  height: 8px;
  background: #fbbf24;
  border-radius: 50%;
  animation: pulse 1.1s infinite ease-in-out;
}

.error-line {
  color: #fca5a5;
  font-size: 12px;
  align-self: center;
}

.controls-area {
  background: rgba(0, 0, 0, 0.25);
  border-radius: 14px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  border: 1px solid rgba(255, 255, 255, 0.06);
  flex-shrink: 0;
}

.mood-row {
  display: flex;
  gap: 8px;
  width: 100%;
  margin-bottom: 2px;
}

.pill {
  flex: 1;
  border: none;
  padding: 8px 4px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 700;
  cursor: pointer;
  color: #0f172a;
  white-space: nowrap;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
}
.pill:hover {
  filter: brightness(1.1);
}
.pill.warm {
  background: #fdba74;
}
.pill.calm {
  background: #93c5fd;
}
.pill.vivid {
  background: #f9a8d4;
}

.input-block {
  display: flex;
  flex-direction: column;
}

.input-block label {
  display: none;
}

.input-block textarea {
  background: rgba(0, 0, 0, 0.22);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 10px;
  padding: 12px;
  color: #e2e8f0;
  font-size: 14px;
  resize: none;
  min-height: 110px;
  height: 110px;
  line-height: 1.5;
  font-family: inherit;
  transition: border-color 0.2s;
  box-sizing: border-box;
}

.input-block textarea:focus {
  outline: none;
  border-color: #60a5fa;
  background: rgba(0, 0, 0, 0.4);
}

.cta-row {
  display: flex;
  gap: 12px;
  align-items: center;
  justify-content: space-between;
}

.primary-btn {
  flex: 1;
  background: linear-gradient(135deg, #3b82f6, #6366f1);
  color: #fff;
  border: none;
  padding: 8px 16px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 14px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 40px;
}

.primary-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.mode-switch {
  display: flex;
  flex-direction: row;
  gap: 8px;
  align-items: center;
  height: 40px;
  align-self: flex-start;
}

.switch-bg {
  background: rgba(0, 0, 0, 0.3);
  padding: 4px;
  border-radius: 8px;
  display: flex;
  height: 100%;
  box-sizing: border-box;
  align-items: center;
}

.pill.tiny {
  padding: 0 12px;
  height: 28px;
  font-size: 12px;
  background: transparent;
  color: #94a3b8;
  border-radius: 6px;
  flex: initial;
}

.pill.tiny.active {
  background: #334155;
  color: #fff;
}

.main-panel {
  display: flex;
  flex-direction: column;
  gap: 14px;
  min-height: 0;
}

.playlist-card {
  background: rgba(30, 41, 59, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 14px;
  padding: 14px 16px;
  display: flex;
  align-items: center;
  gap: 14px;
}

.playlist-card.highlight {
  background: linear-gradient(90deg, rgba(59, 130, 246, 0.1), rgba(167, 139, 250, 0.08));
  border-color: rgba(59, 130, 246, 0.3);
}

.thumb {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: linear-gradient(135deg, #38bdf8, #818cf8);
  display: grid;
  place-items: center;
  font-size: 20px;
  color: #fff;
}

.playlist-info {
  flex: 1;
}

.playlist-title {
  font-weight: 700;
  font-size: 15px;
}

.playlist-meta {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.68);
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}

.track-time {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  min-width: 46px;
  text-align: right;
}

.placeholder-card {
  border: 1px dashed rgba(148, 163, 184, 0.3);
  border-radius: 12px;
  padding: 12px;
  color: rgba(255, 255, 255, 0.7);
}

.track-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 10px;
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.02);
  min-height: 0;
  max-height: 320px;
  overflow-y: auto;
  scrollbar-width: none;
}

.track-list.tall {
  flex: 1;
  overflow-y: auto;
}

.track-list::-webkit-scrollbar {
  width: 0;
  height: 0;
}

.list-head {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
}

.list-head h4 {
  margin: 0;
  font-size: 14px;
}

.muted {
  color: rgba(148, 163, 184, 0.9);
  font-size: 12px;
}

.track-row {
  display: grid;
  grid-template-columns: auto 1fr auto auto;
  gap: 12px;
  align-items: center;
  padding: 10px 12px;
  border-radius: 12px;
  background: #111a2d;
  border: 1px solid rgba(255, 255, 255, 0.07);
}

.track-title {
  font-weight: 700;
  font-size: 14px;
  color: #e9edf7;
}

.track-sub {
  font-size: 12px;
  color: rgba(226, 232, 240, 0.8);
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  align-items: center;
}

.track-cover {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background: linear-gradient(135deg, #6d8cff, #6ce2ff);
  display: grid;
  place-items: center;
  color: #f8fafc;
  font-size: 18px;
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.08),
    0 8px 18px rgba(0, 0, 0, 0.3);
}

.track-row.mini-card {
  grid-template-columns: auto 1fr auto auto;
  padding: 10px 14px;
}

.play-icon-btn {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: linear-gradient(135deg, #4f8bff, #7ae0ff);
  border: none;
  color: #0b1426;
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 10px 22px rgba(79, 139, 255, 0.25);
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}

.play-icon-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 12px 26px rgba(79, 139, 255, 0.35);
}

.insights-panel {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 0;
}

.pie-placeholder {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 14px;
  padding: 16px;
  display: grid;
  place-items: center;
  gap: 10px;
}

.donut-wrap {
  position: relative;
  width: 140px;
  height: 140px;
}

.donut {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: conic-gradient(
    #60a5fa 0 32%,
    #2dd4bf 32% 50%,
    #a78bfa 50% 75%,
    #fb923c 75% 87%,
    #f472b6 87% 100%
  );
  box-shadow:
    inset 0 0 0 10px rgba(0, 0, 0, 0.25),
    0 20px 40px rgba(0, 0, 0, 0.25);
}

.inner-circle {
  position: absolute;
  inset: 18px;
  border-radius: 50%;
  background: rgba(15, 23, 42, 0.9);
  display: grid;
  place-items: center;
  box-shadow: inset 0 0 12px rgba(0, 0, 0, 0.6);
}

.score {
  font-size: 26px;
  font-weight: 800;
}

.inner-circle .label {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.7);
}

@keyframes pulse {
  0% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.1);
    opacity: 0.7;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

@media (max-width: 1280px) {
  .page {
    grid-template-columns: 1fr;
  }

  .panel {
    min-height: auto;
  }

  .chat-panel {
    max-height: none;
  }

  .chat-scroll {
    max-height: 60vh;
  }

  .track-list {
    max-height: 50vh;
  }
}

@media (max-width: 768px) {
  .cta-row {
    flex-direction: column;
    align-items: stretch;
  }

  .panel-header {
    flex-direction: column;
    align-items: flex-start;
  }

  .playlist-card {
    grid-template-columns: 1fr;
  }

  .track-row {
    grid-template-columns: auto 1fr;
    grid-template-rows: auto auto;
    row-gap: 8px;
  }

  .track-time,
  .play-btn {
    justify-self: flex-start;
  }
}
</style>
