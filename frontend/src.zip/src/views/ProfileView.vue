<template>
  <div class="profile-page">
    <header class="page-header">
      <div>
        <p class="eyebrow">个人中心</p>
        <h1>个人资料</h1>
        <p class="muted">管理你的基础信息与数据概览，保持账号形象一致。</p>
      </div>
      <div class="header-actions">
        <button class="ghost-btn" type="button" @click="isEditing ? cancelEdit() : startEdit()" :disabled="saving || !isLoggedIn">
          {{ isEditing ? "取消" : "编辑" }}
        </button>
        <button class="primary-btn" type="button" @click="saveProfile" :disabled="!isEditing || saving || !isLoggedIn">
          {{ saving ? "保存中..." : "保存" }}
        </button>
      </div>
    </header>

    <section class="card base-info">
      <div class="card-title">
        <span>基本信息</span>
        <span class="status-chip">
          <span class="dot online"></span>
          {{ statusText }}
        </span>
      </div>
      <div class="base-grid">
        <div class="avatar-block">
          <div class="avatar-circle">🎵</div>
          <div class="avatar-meta">
            <span v-for="tag in displayTags" :key="tag" class="tag">{{ tag }}</span>
            <span v-if="!displayTags.length" class="tag outline">未设置</span>
          </div>
        </div>
        <div class="field-grid">
          <div class="field">
            <label>姓名</label>
            <template v-if="isEditing">
              <input v-model="form.name" placeholder="请输入姓名" />
            </template>
            <div v-else class="field-value">{{ form.name || "未填写" }}</div>
          </div>
          <div class="field">
            <label>邮箱</label>
            <template v-if="isEditing">
              <input v-model="form.email" type="email" placeholder="请输入邮箱" disabled />
            </template>
            <div v-else class="field-value">{{ form.email || "未填写" }}</div>
          </div>
          <div class="field span-2">
            <label>个人简介</label>
            <template v-if="isEditing">
              <textarea v-model="form.bio" rows="3" placeholder="介绍一下自己"></textarea>
            </template>
            <div v-else class="field-value multiline">
              {{ form.bio || "暂无简介" }}
            </div>
          </div>
          <div class="field span-2">
            <label>标签</label>
            <template v-if="isEditing">
              <input v-model="tagInput" placeholder="用逗号分隔标签，如：已实名,音乐创作者" />
            </template>
            <div v-else class="field-value tag-list">
              <span v-if="displayTags.length" v-for="tag in displayTags" :key="tag" class="tag outline">{{ tag }}</span>
              <span v-else class="muted">未设置标签</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="card stats">
      <div class="card-title">
        <span>个人数据</span>
      </div>
      <div class="stat-grid">
        <div v-for="item in statItems" :key="item.label" class="stat-item">
          <div class="stat-value">{{ item.value }}</div>
          <div class="stat-label">{{ item.label }}</div>
        </div>
      </div>
    </section>

    <section class="card placeholder-card">
      <div class="card-title">
        <span>发布的作品</span>
      </div>
      <div class="placeholder">
        <div class="placeholder-icon">🎧</div>
        <div>
          <div class="placeholder-title">作品区稍后上线</div>
          <div class="placeholder-desc">暂未展示作品卡片，后续可以补充专辑或单曲列表。</div>
        </div>
      </div>
    </section>

    <p v-if="errorMessage" class="banner error-banner">{{ errorMessage }}</p>
    <p v-if="successMessage" class="banner success-banner">{{ successMessage }}</p>
  </div>
</template>

<script setup>
import { computed, reactive, ref, watch, onMounted } from "vue";
import { useAuthStore } from "../stores/auth";

const auth = useAuthStore();
const isLoggedIn = computed(() => auth.isLoggedIn);

const isEditing = ref(false);
const saving = ref(false);
const errorMessage = ref("");
const successMessage = ref("");
const originalSnapshot = ref(null);

const form = reactive({
  name: "",
  email: "",
  bio: "",
  tags: []
});

const tagInput = ref("");

const statusText = computed(() => auth.user?.status || "已激活");

const statItems = computed(() => {
  const stats = auth.user?.stats || {};
  return [
    { label: "总生成次数", value: stats.generations ?? 0 },
    { label: "情绪识别次数", value: stats.emotionDetections ?? 0 },
    { label: "总点赞数", value: stats.likes ?? 0 },
    { label: "本月播放", value: stats.monthlyPlays ?? 0 },
    { label: "播放列表", value: stats.playlists ?? 0 },
    { label: "关注数", value: stats.followers ?? 0 }
  ];
});

const displayTags = computed(() => (Array.isArray(form.tags) ? form.tags : []));

const parseTags = value =>
  (value || "")
    .split(",")
    .map(item => item.trim())
    .filter(Boolean);

const resetForm = () => {
  form.name = "";
  form.email = "";
  form.bio = "";
  form.tags = [];
  tagInput.value = "";
};

const fillForm = user => {
  resetForm();
  if (!user) return;
  form.name = user.name || user.nickname || "";
  form.email = user.email || "";
  form.bio = user.bio || "";
  form.tags = Array.isArray(user.tags) ? user.tags : [];
  tagInput.value = form.tags.join(",");
};

watch(
  () => auth.user,
  user => {
    fillForm(user);
  },
  { immediate: true }
);

const startEdit = () => {
  errorMessage.value = "";
  successMessage.value = "";
  if (!isLoggedIn.value) {
    errorMessage.value = "请先登录后再编辑资料";
    return;
  }
  originalSnapshot.value = JSON.parse(JSON.stringify(form));
  isEditing.value = true;
  tagInput.value = form.tags.join(",");
};

const cancelEdit = () => {
  if (!isEditing.value) return;
  errorMessage.value = "";
  successMessage.value = "";
  const snap = originalSnapshot.value;
  if (snap) {
    form.name = snap.name || "";
    form.email = snap.email || "";
    form.bio = snap.bio || "";
    form.tags = Array.isArray(snap.tags) ? snap.tags : [];
    tagInput.value = form.tags.join(",");
  } else {
    fillForm(auth.user);
  }
  isEditing.value = false;
};

const saveProfile = async () => {
  if (!isEditing.value) return;
  if (!isLoggedIn.value) {
    errorMessage.value = "请登录后再保存";
    return;
  }
  errorMessage.value = "";
  successMessage.value = "";
  saving.value = true;
  form.tags = parseTags(tagInput.value);
  try {
    const payload = {
      username: form.name,
      email: form.email,
      personal_profile: form.bio,
      tags: form.tags
    };
    const user = await auth.updateProfileAction(payload);
    fillForm(user);
    successMessage.value = "保存成功";
    isEditing.value = false;
  } catch (err) {
    errorMessage.value = err?.message || "保存失败";
  } finally {
    saving.value = false;
  }
};

onMounted(async () => {
  try {
    await auth.refreshProfile();
    fillForm(auth.user);
  } catch (err) {
    errorMessage.value = err?.message || "获取资料失败";
  }
});
</script>

<style scoped>
.profile-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 18px 20px;
  border-radius: 16px;
  background: linear-gradient(135deg, rgba(23, 37, 84, 0.4), rgba(8, 20, 46, 0.8));
  border: 1px solid rgba(148, 163, 184, 0.24);
}

.eyebrow {
  font-size: 12px;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.55);
  margin-bottom: 4px;
}

h1 {
  font-size: 20px;
  margin: 0;
}

.muted {
  margin-top: 6px;
  color: rgba(255, 255, 255, 0.6);
  font-size: 13px;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.ghost-btn,
.primary-btn {
  height: 34px;
  padding: 0 14px;
  border-radius: 10px;
  border: 1px solid rgba(148, 163, 184, 0.45);
  background: rgba(255, 255, 255, 0.04);
  color: #e5e7eb;
  cursor: pointer;
  font-size: 13px;
  transition: all 0.16s ease-out;
}

.ghost-btn:disabled,
.primary-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.primary-btn {
  background: linear-gradient(135deg, #3b82f6, #8b5cf6);
  border: none;
  box-shadow: 0 12px 30px rgba(59, 130, 246, 0.25);
}

.ghost-btn:hover:not(:disabled),
.primary-btn:hover:not(:disabled) {
  transform: translateY(-1px);
}

.card {
  padding: 18px 20px;
  border-radius: 16px;
  background: rgba(15, 23, 42, 0.92);
  border: 1px solid rgba(148, 163, 184, 0.2);
  box-shadow: 0 16px 50px rgba(15, 23, 42, 0.7);
}

.card-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
  font-weight: 600;
}

.status-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  background: rgba(34, 197, 94, 0.12);
  color: #a7f3d0;
  border-radius: 999px;
  border: 1px solid rgba(34, 197, 94, 0.25);
}

.dot {
  width: 8px;
  height: 8px;
  border-radius: 999px;
}

.dot.online {
  background: #22c55e;
  box-shadow: 0 0 0 4px rgba(34, 197, 94, 0.14);
}

.base-info {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.base-grid {
  display: grid;
  grid-template-columns: 200px 1fr;
  gap: 18px;
}

.avatar-block {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}

.avatar-circle {
  width: 96px;
  height: 96px;
  border-radius: 999px;
  background: linear-gradient(135deg, #4f46e5, #f97316);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30px;
  font-weight: 700;
}

.avatar-meta {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  justify-content: center;
}

.tag {
  padding: 4px 10px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.08);
  font-size: 12px;
  color: #e5e7eb;
}

.tag.outline {
  background: rgba(59, 130, 246, 0.14);
  color: #bfdbfe;
  border: 1px solid rgba(59, 130, 246, 0.4);
}

.field-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.field label {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.7);
}

.field-value {
  padding: 10px 12px;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(148, 163, 184, 0.2);
}

.field-value.multiline {
  min-height: 68px;
  line-height: 1.5;
}

.field input,
.field textarea,
.mini-input input {
  width: 100%;
  padding: 10px 12px;
  border-radius: 10px;
  border: 1px solid rgba(148, 163, 184, 0.35);
  background: rgba(255, 255, 255, 0.04);
  color: #e5e7eb;
  outline: none;
}

.field textarea {
  resize: vertical;
}

.mini-input {
  width: 100%;
}

.span-2 {
  grid-column: span 2;
}

.tag-list {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.stats .stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 12px;
}

.stat-item {
  padding: 14px 12px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.02);
  border: 1px solid rgba(148, 163, 184, 0.18);
}

.stat-value {
  font-size: 22px;
  font-weight: 700;
  margin-bottom: 6px;
}

.stat-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.65);
}

.placeholder-card .placeholder {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.02);
  border: 1px dashed rgba(148, 163, 184, 0.25);
}

.placeholder-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: rgba(59, 130, 246, 0.14);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
}

.placeholder-title {
  font-weight: 600;
}

.placeholder-desc {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.65);
}

.banner {
  margin: 0;
  padding: 10px 12px;
  border-radius: 10px;
  font-size: 13px;
}

.error-banner {
  background: rgba(248, 113, 113, 0.12);
  border: 1px solid rgba(248, 113, 113, 0.4);
  color: #fecdd3;
}

.success-banner {
  background: rgba(16, 185, 129, 0.12);
  border: 1px solid rgba(16, 185, 129, 0.35);
  color: #bbf7d0;
}

@media (max-width: 900px) {
  .base-grid {
    grid-template-columns: 1fr;
  }

  .field-grid {
    grid-template-columns: 1fr;
  }

  .span-2 {
    grid-column: span 1;
  }

  .page-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }
}
</style>
