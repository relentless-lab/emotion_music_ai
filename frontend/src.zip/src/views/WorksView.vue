<template>
  <div class="works-page">
    <h2 class="page-title">我的作品</h2>

    <section class="list-card">
      <div v-if="loading" class="state">加载中...</div>
      <div v-else-if="displayWorks.length === 0" class="state">暂无作品</div>
      <div v-else class="work-list">
        <WorkItem
          v-for="item in displayWorks"
          :key="item.id"
          :item="item"
          @delete="handleDelete"
        />
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted } from "vue";
import { storeToRefs } from "pinia";
import WorkItem from "@/components/WorkItem.vue";
import { useWorksStore } from "@/stores/works";

const worksStore = useWorksStore();
const { list: works, loading } = storeToRefs(worksStore);

const displayWorks = computed(() => works.value || []);

onMounted(() => {
  worksStore.loadWorks();
});

const handleDelete = id => {
  worksStore.removeWork(id);
};
</script>

<style scoped>
.works-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
  color: #e5e7eb;
}

.page-title {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  color: #e6ebf5;
}

.list-card {
  padding: 6px 6px 12px;
  border-radius: 12px;
  background: #0b1627;
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.work-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.state {
  padding: 16px;
  text-align: center;
  color: rgba(255, 255, 255, 0.78);
}
</style>
