﻿<template>
  <div class="page-shell">
    <div v-if="showLoginPanel" class="login-modal" @click.self="ui.closeLoginPanel()">
      <section class="panel login-panel" :class="{ register: ui.authMode === 'register' }">
        <div class="login-header">
          <div class="login-title">
            {{ ui.authMode === "login" ? "登录您的账户" : "注册新用户账户" }}
          </div>
          <button class="close-btn" type="button" @click="ui.closeLoginPanel()">关闭</button>
        </div>

        <form
          v-if="ui.authMode === 'login'"
          class="auth-form"
          @submit.prevent="handleLogin"
        >
          <label class="field">
            <span>请输入用户名</span>
            <input
              v-model="loginForm.username"
              type="text"
              placeholder="请输入用户名"
              required
            />
          </label>
          <label class="field">
            <span>密码</span>
            <input
              v-model="loginForm.password"
              type="password"
              placeholder="请输入密码"
              required
            />
          </label>

          <button class="cta primary" type="submit" :disabled="auth.loading">
            {{ auth.loading ? "登录中..." : "登录" }}
          </button>
          <p v-if="registerSuccess && ui.authMode === 'login'" class="success-text">{{ registerSuccess }}</p>
          <p v-if="auth.error" class="error-text">{{ auth.error }}</p>
        </form>

        <form
          v-else
          class="auth-form register-form"
          @submit.prevent="handleRegister"
        >
          <label class="field">
            <span>用户名</span>
            <input v-model="registerForm.username" type="text" placeholder="请输入用户名" required />
          </label>
          <label class="field">
            <span>电子邮箱</span>
            <input v-model="registerForm.email" type="email" placeholder="请输入电子邮箱" required />
          </label>
          <label class="field code-field">
            <span>验证码</span>
            <div class="code-row">
              <input v-model="registerForm.code" type="text" placeholder="请输入邮箱验证码" required />
              <button class="ghost-btn" type="button">获取验证码</button>
            </div>
          </label>
          <label class="field">
            <span>密码</span>
            <input v-model="registerForm.password" type="password" placeholder="请输入密码" required />
          </label>
          <label class="field">
            <span>确认密码</span>
            <input
              v-model="registerForm.confirm"
              type="password"
              placeholder="再次输入密码"
              required
            />
          </label>

          <div class="terms">
            <input type="checkbox" required />
            <span>我同意服务条款和隐私政策</span>
          </div>

          <button class="cta primary" type="submit" :disabled="auth.loading">
            {{ auth.loading ? "注册中..." : "注册" }}
          </button>
          <p v-if="auth.error && ui.authMode === 'register'" class="error-text">{{ auth.error }}</p>
        </form>

        <div class="register-row">
          <span
            v-if="ui.authMode === 'login'"
            class="register-link"
            @click="ui.openRegisterPanel()"
          >
            还没有账号？立即注册
          </span>
          <span
            v-else
            class="register-link"
            @click="ui.openLoginPanel()"
          >
            已有账号？立即登录
          </span>
        </div>
      </section>
    </div>

    <div v-if="showLoginSuccessToast" class="toast success-toast">登录成功</div>

    <section class="panel carousel-panel">
      <Carousel :slides="carouselSlides" @slide-click="handleSlideClick" />
    </section>

    <div class="grid">
      <section class="panel">
        <div class="section-header">
          <div>
            <p class="eyebrow">热门精选</p>
            <h2>热门歌曲推荐</h2>
          </div>
          <span class="view-all">查看全部</span>
        </div>
        <div class="scroll-area">
          <div class="list">
            <SongCard v-for="song in songs" :key="song.id" :song="song" />
          </div>
        </div>
      </section>

      <section class="panel">
        <div class="section-header">
          <div>
            <p class="eyebrow">创作者</p>
            <h2>推荐创作者</h2>
          </div>
          <span class="view-all">查看全部</span>
        </div>
        <div class="scroll-area">
          <div class="list compact">
            <CreatorCard v-for="creator in creators" :key="creator.id" :creator="creator" />
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { computed, reactive, ref, onMounted, onBeforeUnmount } from "vue";
import { useRouter } from "vue-router";
import Carousel from "./components/Carousel.vue";
import SongCard from "./components/SongCard.vue";
import CreatorCard from "./components/CreatorCard.vue";
import { useAuthStore } from "../stores/auth";
import { useUiStore } from "../stores/ui";

const auth = useAuthStore();
const ui = useUiStore();
const router = useRouter();

const loginForm = reactive({
  username: "",
  password: ""
});

const registerForm = reactive({
  username: "",
  email: "",
  code: "",
  password: "",
  confirm: ""
});

const registerSuccess = ref("");
const showLoginSuccessToast = ref(false);
let loginSuccessTimer;

const triggerLoginSuccessToast = () => {
  if (loginSuccessTimer) {
    clearTimeout(loginSuccessTimer);
  }
  showLoginSuccessToast.value = true;
  loginSuccessTimer = setTimeout(() => {
    showLoginSuccessToast.value = false;
  }, 1000);
};

const handleLogin = async () => {
  auth.error = "";
  registerSuccess.value = "";
  const username = loginForm.username.trim();
  const password = loginForm.password;
  if (!username || !password) {
    auth.error = "请填写用户名和密码";
    return;
  }
  try {
    await auth.loginAction({ username, password });
    triggerLoginSuccessToast();
    loginForm.password = "";
    ui.closeLoginPanel();
  } catch (err) {
    // error 已写入 store
  }
};

const handleRegister = async () => {
  auth.error = "";
  registerSuccess.value = "";
  const username = registerForm.username.trim();
  const email = registerForm.email.trim();
  const password = registerForm.password;
  const confirm = registerForm.confirm;

  if (!username || !email || !password || !confirm) {
    auth.error = "请完整填写注册信息";
    return;
  }
  if (password !== confirm) {
    auth.error = "两次密码不一致";
    return;
  }

  try {
    await auth.registerAction({
      username,
      email,
      code: registerForm.code,
      password
    });
    registerSuccess.value = "注册成功，请登录";
    loginForm.username = username;
    ui.setAuthMode("login");
  } catch (err) {
    // error ��д�� store
  }
};

const showLoginPanel = computed(() => ui.showLoginPanel && !auth.isLoggedIn);

onMounted(() => {
  auth.refreshProfile();
});

onBeforeUnmount(() => {
  if (loginSuccessTimer) {
    clearTimeout(loginSuccessTimer);
  }
});

const carouselSlides = ref([
  {
    image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1200&h=400&fit=crop",
    title: "音乐生成",
    description: "使用 AI 一键生成专属音乐作品",
    path: "/generate"
  },
  {
    image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=1200&h=400&fit=crop",
    title: "情绪识别",
    description: "通过音频分析识别当前情绪状态",
    path: "/emotion"
  },
  {
    image: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=1200&h=400&fit=crop",
    title: "我的作品",
    description: "管理和查看您创建的音乐作品",
    path: "/works"
  }
]);

const handleSlideClick = payload => {
  const path = payload?.slide?.path;
  if (path) {
    router.push(path);
  }
};

const songs = ref([
  {
    id: 1,
    title: "Used To Feel Like Home",
    genres: ["acoustic pop", "indie folk", "cinematic"],
    platform: "MusicGOO",
    mood: "delight",
    stats: { plays: "32K", likes: "11K", comments: "24" }
  },
  {
    id: 2,
    title: "Got A Move",
    genres: ["R&B", "Soul", "Electronic", "Funk", "Synth"],
    platform: "Cutting Edge",
    mood: "upbeat",
    stats: { plays: "3.5K", likes: "89", comments: "8" }
  },
  {
    id: 3,
    title: "Summer Vibes",
    genres: ["Pop", "Dance", "Electronic"],
    platform: "MusicGOO",
    mood: "happy",
    stats: { plays: "15K", likes: "3.2K", comments: "45" }
  },
  {
    id: 4,
    title: "Midnight Dreams",
    genres: ["R&B", "Soul", "Lo-fi"],
    platform: "ChillBeats",
    mood: "relaxing",
    stats: { plays: "28K", likes: "8.7K", comments: "156" }
  },
  {
    id: 5,
    title: "Electric Pulse",
    genres: ["EDM", "House", "Electronic"],
    platform: "BassDrop",
    mood: "energetic",
    stats: { plays: "42K", likes: "15K", comments: "89" }
  },
  {
    id: 6,
    title: "Neon Nights",
    genres: ["Synthwave", "Electronic"],
    platform: "BassDrop",
    mood: "nostalgic",
    stats: { plays: "21K", likes: "6.3K", comments: "54" }
  }
]);

const creators = ref([
  {
    id: 1,
    name: "Timotheus",
    followers: "5.2K followers",
    handle: "@timotheus",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: 2,
    name: "Brutus",
    followers: "17K followers",
    handle: "@brutus",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: 3,
    name: "EvilTyremancer",
    followers: "14K followers",
    handle: "@eviltyremancer",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: 4,
    name: "MusicMaster",
    followers: "23K followers",
    handle: "@musicmaster",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: 5,
    name: "BeatMaker",
    followers: "8.7K followers",
    handle: "@beatmaker",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face"
  }
]);
</script>

<style scoped>
.page-shell {
  height: 100%;
  min-height: 100%;
  overflow-y: auto;
  padding: 12px 12px 32px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  box-sizing: border-box;
}

.panel {
  background: rgba(15, 23, 42, 0.86);
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 18px;
  box-shadow: 0 18px 50px rgba(15, 23, 42, 0.6);
  padding: 20px;
  backdrop-filter: blur(8px);
}

.login-modal {
  position: fixed;
  inset: 0;
  background: rgba(3, 7, 18, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  padding: 16px;
}

.login-panel {
  padding: 14px 14px 16px;
  max-width: 300px;
  width: 100%;
  margin-left: -20px;
}

.login-panel.register {
  max-width: 360px;
}

.auth-form {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-top: 12px;
}

.auth-form .field {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.auth-form .field span {
  color: #f9fafb;
  font-weight: 600;
  font-size: 14px;
}

.auth-form input {
  height: 40px;
  border-radius: 8px;
  border: 1px solid rgba(148, 163, 184, 0.35);
  background: rgba(12, 16, 26, 0.95);
  color: #f3f4f6;
  padding: 0 12px;
  outline: none;
}

.auth-form input:focus {
  border-color: rgba(79, 133, 255, 0.9);
  box-shadow: 0 0 0 2px rgba(79, 133, 255, 0.35);
}

.register-form {
  gap: 10px;
}

.code-field .code-row {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 8px;
  align-items: center;
}

.ghost-btn {
  height: 40px;
  padding: 0 12px;
  border-radius: 8px;
  border: 1px solid rgba(148, 163, 184, 0.35);
  background: rgba(255, 255, 255, 0.06);
  color: #e5e7eb;
  cursor: pointer;
  font-weight: 600;
}

.ghost-btn:hover {
  border-color: rgba(79, 133, 255, 0.8);
}

.cta {
  height: 42px;
  padding: 0 14px;
  border-radius: 10px;
  border: none;
  color: #f8fafc;
  font-weight: 700;
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  box-shadow: 0 10px 22px rgba(59, 130, 246, 0.3);
}

.cta.primary {
  background: #4f85ff;
}

.login-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}

.cta:hover {
  transform: translateY(-1px);
}

.login-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.login-title {
  text-align: center;
  font-weight: 700;
}

.error-text {
  color: #f87171;
  font-size: 13px;
}

.success-text {
  color: #10b981;
  font-size: 13px;
}

.close-btn {
  background: none;
  border: none;
  color: rgba(229, 231, 235, 0.9);
  cursor: pointer;
  font-weight: 600;
  padding: 6px 8px;
  border-radius: 8px;
  transition: background 0.15s ease;
}

.close-btn:hover {
  background: rgba(255, 255, 255, 0.04);
}

.register-row {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 14px;
  color: rgba(255, 255, 255, 0.8);
  font-size: 13px;
}

.register-link {
  cursor: pointer;
}

.register-link:hover {
  color: #9cbcff;
}

.terms {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: rgba(229, 231, 235, 0.85);
}

.terms input {
  width: 14px;
  height: 14px;
}

.carousel-panel {
  padding: 18px 18px 22px;
}

.grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 18px;
  min-height: 0;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.section-header h2 {
  margin: 4px 0 0;
  font-size: 18px;
}

.eyebrow {
  font-size: 12px;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.6);
}

.view-all {
  font-size: 13px;
  color: #60a5fa;
  cursor: pointer;
  font-weight: 600;
  transition: color 0.15s ease;
}

.view-all:hover {
  color: #7cc1ff;
}

.scroll-area {
  border-radius: 14px;
  border: 1px solid rgba(148, 163, 184, 0.16);
  background: rgba(255, 255, 255, 0.02);
  overflow-y: auto;
  max-height: 70vh;
  scrollbar-width: none;
}

.toast {
  position: fixed;
  top: 18px;
  left: 50%;
  transform: translateX(-50%);
  padding: 10px 16px;
  border-radius: 12px;
  font-weight: 700;
  color: #071c12;
  background: linear-gradient(135deg, rgba(16, 185, 129, 0.96), rgba(52, 211, 153, 0.96));
  border: 1px solid rgba(74, 222, 128, 0.4);
  box-shadow: 0 12px 32px rgba(16, 185, 129, 0.3);
  z-index: 10000;
  animation: toast-in 0.18s ease;
  letter-spacing: 0.02em;
}

@keyframes toast-in {
  from {
    opacity: 0;
    transform: translate(-50%, -6px);
  }
  to {
    opacity: 1;
    transform: translate(-50%, 0);
  }
}

.scroll-area::-webkit-scrollbar {
  width: 0;
  height: 0;
}

.list {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 14px;
  height: auto;
}

.list.compact {
  gap: 10px;
}

.list::-webkit-scrollbar {
  width: 8px;
}

.list::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.03);
}

.list::-webkit-scrollbar-thumb {
  background: rgba(148, 163, 184, 0.45);
  border-radius: 4px;
}

.list::-webkit-scrollbar-thumb:hover {
  background: rgba(148, 163, 184, 0.6);
}

@media (max-width: 1100px) {
  .grid {
    grid-template-columns: 1.4fr 1fr;
  }
}

@media (max-width: 900px) {
  .grid {
    grid-template-columns: 1fr;
  }

  .login-grid {
    grid-template-columns: 1fr;
  }

  .panel-header {
    flex-direction: column;
    align-items: flex-start;
  }

  .cta {
    align-self: flex-start;
  }
}

@media (max-width: 600px) {
  .page-shell {
    padding: 10px 10px 28px;
  }

  .panel {
    padding: 16px;
  }
}
</style>