<template>
  <div class="history-page">
    <header class="page-header">
      <div>
        <h2>历史记录</h2>
      </div>
    </header>

    <section class="list-card">
      <div v-if="loading" class="state">加载中...</div>
      <div v-else-if="error" class="state error">
        <span>{{ error }}</span>
        <button class="ghost" @click="refresh">重试</button>
      </div>
      <div v-else-if="historyList.length === 0" class="state">暂无记录</div>
      <div v-else class="history-list">
        <HistoryItem v-for="item in historyList" :key="item.id" :item="item" />
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted } from "vue";
import { storeToRefs } from "pinia";
import { useHistoryStore } from "@/stores/history";
import HistoryItem from "@/components/HistoryItem.vue";

const historyStore = useHistoryStore();
const { items, loading, error } = storeToRefs(historyStore);

const historyList = computed(() => items.value || []);
const refresh = () => historyStore.loadHistory();

onMounted(() => {
  refresh();
});

</script>

<style scoped>
.history-page {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 6px;
}

.page-title {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  color: #e6ebf5;
}

.list-card {
  padding: 6px 8px 10px;
  border-radius: 12px;
  background: #0b1627;
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.history-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.state {
  padding: 16px;
  text-align: center;
  color: rgba(255, 255, 255, 0.78);
  background: rgba(255, 255, 255, 0.02);
  border: 1px dashed rgba(148, 163, 184, 0.25);
  border-radius: 12px;
}

.state.error {
  color: #fca5a5;
  background: rgba(248, 113, 113, 0.08);
  border-color: rgba(248, 113, 113, 0.3);
}

.ghost {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(148, 163, 184, 0.3);
  color: #e5e7eb;
  padding: 8px 12px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.ghost:hover {
  border-color: rgba(59, 130, 246, 0.6);
  box-shadow: 0 10px 22px rgba(59, 130, 246, 0.25);
}

@media (max-width: 820px) {
}
</style>
