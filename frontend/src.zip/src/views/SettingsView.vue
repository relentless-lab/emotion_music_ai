<template>
  <div class="settings-page">
    <header class="page-header">
      <h1>系统设置</h1>
      <button class="primary-btn">
        <span class="icon">💾</span>
        保存设置
      </button>
    </header>

    <section class="section">
      <div class="section-title">音乐生成设置</div>
      <div class="field">
        <label for="music-length">生成音乐长度（秒）</label>
        <input
          id="music-length"
          v-model="form.musicLength"
          type="text"
          class="input"
          placeholder="例如 60 秒"
        />
      </div>
    </section>

    <section class="section">
      <div class="section-title">情绪识别设置</div>
      <div class="field">
        <label for="emotion-mode">情绪识别说明</label>
        <input
          id="emotion-mode"
          v-model="form.emotionMode"
          type="text"
          class="input"
          placeholder="例如 高精度模式（更准确的情绪分析）"
        />
      </div>
    </section>

    <section class="section">
      <div class="section-title">音频质量设置</div>
      <div class="sub-title">生成音频质量</div>
      <div class="options">
        <label class="option">
          <input v-model="form.quality" type="radio" value="standard" />
          <span>标准质量（文件较小，生成速度快）</span>
        </label>
        <label class="option">
          <input v-model="form.quality" type="radio" value="high" />
          <span>高质量（文件较大，生成速度较慢）</span>
        </label>
        <label class="option">
          <input v-model="form.quality" type="radio" value="lossless" />
          <span>无损质量（文件最大，生成速度最慢）</span>
        </label>
      </div>

      <div class="field language">
        <label for="language">语言设置</label>
        <select id="language" v-model="form.language" class="select">
          <option value="zh-cn">简体中文</option>
          <option value="zh-tw">繁體中文</option>
          <option value="en">English</option>
        </select>
      </div>
    </section>
  </div>
</template>

<script setup >
import { reactive } from "vue";

const form = reactive({
  musicLength: "60秒（默认长度）",
  emotionMode: "高精度模式（更准确的情绪分析）",
  quality: "standard",
  language: "zh-cn"
});
</script>

<style scoped>
.settings-page {
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding: 10px;
  color: #e5e7eb;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: linear-gradient(135deg, rgba(17, 24, 39, 0.92), rgba(15, 23, 42, 0.88));
  border: 1px solid rgba(148, 163, 184, 0.28);
  border-radius: 16px;
  padding: 16px 18px;
  box-shadow: 0 14px 36px rgba(5, 12, 32, 0.5);
}

.page-header h1 {
  margin: 0;
  font-size: 20px;
}

.primary-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  border: none;
  border-radius: 10px;
  background: linear-gradient(135deg, #3b82f6, #60a5fa);
  color: #f8fafc;
  font-weight: 700;
  cursor: pointer;
  box-shadow: 0 10px 24px rgba(59, 130, 246, 0.3);
}

.primary-btn:hover {
  transform: translateY(-1px);
}

.section {
  background: rgba(15, 23, 42, 0.9);
  border: 1px solid rgba(148, 163, 184, 0.16);
  border-radius: 14px;
  padding: 16px 18px 20px;
  box-shadow: 0 10px 30px rgba(5, 12, 32, 0.45);
}

.section + .section {
  border-top: 1px solid rgba(148, 163, 184, 0.12);
}

.section-title {
  font-weight: 800;
  font-size: 15px;
  margin-bottom: 12px;
}

.sub-title {
  font-weight: 700;
  margin: 8px 0 10px;
  color: rgba(255, 255, 255, 0.86);
}

.field {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 14px;
  flex-wrap: wrap;
}

.field label {
  min-width: 120px;
  color: rgba(255, 255, 255, 0.85);
  font-weight: 600;
}

.input,
.select {
  width: 260px;
  height: 38px;
  border-radius: 10px;
  border: 1px solid rgba(148, 163, 184, 0.3);
  background: rgba(255, 255, 255, 0.04);
  color: #e5e7eb;
  padding: 0 12px;
  outline: none;
  font-size: 14px;
}

.input:focus,
.select:focus {
  border-color: rgba(59, 130, 246, 0.7);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
}

.options {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-left: 6px;
  margin-bottom: 8px;
}

.option {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  color: rgba(255, 255, 255, 0.9);
  font-weight: 600;
}

.option input {
  width: 16px;
  height: 16px;
}

.language {
  margin-top: 6px;
}

.icon {
  font-size: 14px;
}

@media (max-width: 720px) {
  .field {
    flex-direction: column;
    align-items: flex-start;
  }

  .field label {
    min-width: 0;
  }
}
</style>

