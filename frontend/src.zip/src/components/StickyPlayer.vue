<template>
  <div class="sticky-player">
    <div class="player-shell">
      <div class="track-info">
        <div class="cover" :style="coverStyle">
          <div class="vinyl"></div>
          <span v-if="!currentTrack?.cover" class="cover-fallback">♪</span>
        </div>
        <div class="text">
          <div class="title-row">
            <div class="title">{{ currentTrack?.title ?? "未选择歌曲" }}</div>
            <span v-if="currentTrack?.album" class="tag">{{ currentTrack.album }}</span>
          </div>
          <div class="subtitle">
            <span>{{ currentTrack?.artist ?? "AI 播放器" }}</span>
            <span v-if="currentTrack?.mood">· {{ currentTrack.mood }}</span>
          </div>
          <div class="progress-row">
            <span class="time">{{ formatTime(player.currentTime) }}</span>
            <input
              class="slider"
              type="range"
              min="0"
              max="100"
              step="0.1"
              :value="progress"
              @input="onSeek"
            />
            <span class="time">{{ formatTime(player.duration) }}</span>
          </div>
        </div>
        <button
          class="icon-btn ghost"
          :class="{ active: isLiked }"
          :title="isLiked ? '取消收藏' : '收藏'"
          @click="toggleLike"
        >
          {{ isLiked ? "❤" : "♡" }}
        </button>
      </div>

      <div class="control-cluster">
        <div class="primary-controls">
          <button class="icon-btn ghost" :class="{ active: player.shuffle }" title="随机播放" @click="player.toggleShuffle">
            🔀
          </button>
          <button class="icon-btn ghost" title="上一首" @click="player.prev">⏮</button>
          <button class="play-btn" title="播放/暂停" @click="player.togglePlay">
            {{ player.isPlaying ? "⏸" : "▶" }}
          </button>
          <button class="icon-btn ghost" title="下一首" @click="player.next">⏭</button>
          <button class="icon-btn ghost" :class="{ active: player.repeatMode !== 'off' }" :title="repeatLabel" @click="player.cycleRepeatMode">
            🔁
            <span v-if="player.repeatMode === 'one'" class="badge">1</span>
          </button>
        </div>

        <div class="secondary-controls">
          <div class="volume">
            <button class="icon-btn ghost" :title="player.isMuted ? '取消静音' : '静音'" @click="player.toggleMute">
              {{ player.isMuted ? "🔇" : "🔊" }}
            </button>
            <input
              class="slider small"
              type="range"
              min="0"
              max="100"
              step="1"
              :value="volume"
              @input="onVolumeChange"
            />
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { computed, onMounted } from "vue";
import { usePlayerStore } from "../stores/player";

const player = usePlayerStore();

const currentTrack = computed(() => player.currentTrack);
const progress = computed(() => {
  if (!player.duration) return 0;
  return Math.min(100, (player.currentTime / player.duration) * 100);
});
const volume = computed(() => (player.isMuted ? 0 : player.volume * 100));
const repeatLabel = computed(() => {
  if (player.repeatMode === "one") return "单曲循环";
  if (player.repeatMode === "all") return "列表循环";
  return "不循环";
});
const isLiked = computed(() => {
  if (!currentTrack.value) return false;
  return player.likedTrackIds.includes(currentTrack.value.id);
});

const coverStyle = computed(() => {
  if (currentTrack.value?.cover) {
    return { backgroundImage: `url(${currentTrack.value.cover})` };
  }
  return { backgroundImage: "linear-gradient(135deg, #1f2937, #0f172a)" };
});

const formatTime = (seconds) => {
  if (!seconds && seconds !== 0) return "0:00";
  const safe = Math.max(0, Math.floor(seconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
};

const onSeek = (event) => {
  const value = Number(event.target.value) / 100;
  player.seekTo(value);
};

const onVolumeChange = (event) => {
  const value = Number(event.target.value) / 100;
  player.setVolume(value);
};

const toggleLike = () => {
  if (!currentTrack.value) return;
  player.toggleLike(currentTrack.value.id);
};

onMounted(() => {
  player.initAudio();
});
</script>

<style scoped>
:global(body) {
  --player-bg: rgba(15, 23, 42, 0.88);
  --player-border: rgba(255, 255, 255, 0.06);
  --player-accent: linear-gradient(120deg, #22d3ee, #6366f1);
  --player-text: #e2e8f0;
  --player-muted: #94a3b8;
}

.sticky-player {
  position: fixed;
  left: 18px;
  right: 24px;
  bottom: 14px;
  z-index: 30;
  pointer-events: none;
}

.player-shell {
  display: grid;
  grid-template-columns: minmax(260px, 0.9fr) 1.1fr;
  gap: 20px;
  background: var(--player-bg);
  border: 1px solid var(--player-border);
  border-radius: 16px;
  box-shadow: 0 25px 80px rgba(0, 0, 0, 0.45);
  padding: 14px 18px;
  backdrop-filter: blur(16px);
  pointer-events: auto;
}

.track-info {
  display: grid;
  grid-template-columns: auto 1fr auto;
  gap: 12px;
  align-items: center;
}

.cover {
  width: 70px;
  height: 70px;
  border-radius: 14px;
  background-size: cover;
  background-position: center;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 22px rgba(0, 0, 0, 0.4);
}

.vinyl {
  position: absolute;
  inset: 6px;
  border-radius: 10px;
  background: radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.25), transparent 50%), #0b1224;
  opacity: 0;
  transition: opacity 0.25s ease;
}

.cover:hover .vinyl {
  opacity: 0.8;
}

.cover-fallback {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  color: #cbd5e1;
  font-size: 22px;
}

.text {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.title-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.title {
  font-weight: 700;
  color: var(--player-text);
  letter-spacing: 0.01em;
  font-size: 15px;
}

.tag {
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11px;
  border: 1px solid var(--player-border);
  color: var(--player-muted);
}

.subtitle {
  font-size: 12px;
  color: var(--player-muted);
  display: flex;
  gap: 6px;
}

.progress-row {
  display: grid;
  grid-template-columns: 44px 1fr 44px;
  align-items: center;
  gap: 10px;
  margin-top: 2px;
}

.time {
  font-size: 11px;
  color: var(--player-muted);
  font-feature-settings: "tnum";
}

.control-cluster {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  flex-wrap: nowrap;
  width: 100%;
  padding-left: 12px;
}

.primary-controls {
  display: flex;
  align-items: center;
  gap: 10px;
  justify-content: flex-start;
}

.secondary-controls {
  display: flex;
  align-items: center;
  gap: 12px;
  justify-content: flex-end;
}

.icon-btn,
.pill {
  border: 1px solid var(--player-border);
  background: rgba(255, 255, 255, 0.02);
  color: var(--player-text);
  border-radius: 12px;
  cursor: pointer;
  transition: transform 0.12s ease, border-color 0.12s ease, background 0.12s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

.icon-btn {
  width: 36px;
  height: 36px;
  font-size: 15px;
}

.icon-btn.ghost:hover,
.pill.ghost:hover {
  transform: translateY(-1px);
  border-color: rgba(99, 102, 241, 0.6);
}

.icon-btn.active,
.pill.active {
  border-color: rgba(99, 102, 241, 0.8);
  background: rgba(99, 102, 241, 0.14);
}

.play-btn {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  border: none;
  background-image: var(--player-accent);
  color: #0b1021;
  font-size: 18px;
  font-weight: 800;
  box-shadow: 0 12px 30px rgba(99, 102, 241, 0.35);
  cursor: pointer;
  transition: transform 0.12s ease, box-shadow 0.12s ease;
}

.play-btn:hover {
  transform: translateY(-2px) scale(1.02);
  box-shadow: 0 16px 36px rgba(99, 102, 241, 0.45);
}

.badge {
  font-size: 10px;
  margin-left: 2px;
}

.pill {
  padding: 8px 12px;
  font-size: 12px;
  font-weight: 600;
}

.volume {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 160px;
}

.slider {
  appearance: none;
  width: 100%;
  height: 6px;
  border-radius: 999px;
  background: linear-gradient(90deg, rgba(99, 102, 241, 0.3), rgba(34, 211, 238, 0.4));
  outline: none;
  cursor: pointer;
  position: relative;
}

.slider.small {
  height: 5px;
}

.slider::-webkit-slider-thumb {
  appearance: none;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 0 12px rgba(99, 102, 241, 0.7);
  border: 2px solid #0b1224;
}

.slider::-moz-range-thumb {
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 0 12px rgba(99, 102, 241, 0.7);
  border: 2px solid #0b1224;
}

@media (max-width: 1100px) {
  .player-shell {
    grid-template-columns: 1fr;
  }
  .control-cluster {
    order: 2;
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
    width: 100%;
  }
  .secondary-controls {
    width: 100%;
    justify-content: space-between;
  }
}

@media (max-width: 720px) {
  .player-shell {
    padding: 12px;
  }
  .track-info {
    grid-template-columns: auto 1fr;
    grid-template-areas:
      "cover title"
      "cover subtitle";
  }
  .track-info .icon-btn {
    display: none;
  }
  .progress-row {
    grid-template-columns: 38px 1fr 38px;
  }
  .secondary-controls {
    flex-wrap: wrap;
    gap: 8px;
  }
  .volume {
    min-width: 0;
    width: 100%;
  }
}
</style>
