<template>
  <div class="work-row">
    <div class="work-left">
      <div class="thumb">{{ displayIcon }}</div>
      <div class="text">
        <div class="name">{{ item.name }}</div>
        <div class="meta-line">{{ metaLine }}</div>
      </div>
    </div>
    <div class="work-actions">
      <button class="action primary" type="button">
        <span class="bolt">⚡</span>
        发布
      </button>
      <button class="action square" type="button" title="播放">▶</button>
      <button class="action square" type="button" title="下载">⬇</button>
      <button
        class="action square"
        type="button"
        title="删除"
        :disabled="disableDelete"
        @click="$emit('delete', item.id)"
      >
        🗑
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed } from "vue";

const props = defineProps({
  item: {
    type: Object,
    required: true
  },
  disableDelete: {
    type: Boolean,
    default: false
  }
});

defineEmits(["delete"]);

const displayIcon = computed(() => "🎵" || props.item?.icon );

const formatTime = value => {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString("zh-CN", { hour12: false });
};

const metaLine = computed(() => {
  const parts = [];
  const source = props.item?.source || (props.item?.type?.includes("上传") ? "上传的音乐" : "生成的音乐");
  if (source) parts.push(source);
  const time = formatTime(props.item?.createdAt);
  if (time) parts.push(time);
  const meta = (() => {
    const value = props.item;
    if (typeof value.meta === "string" && value.meta.trim()) {
      return value.meta.replace(/[,，|\\/]+/g, " · ").replace(/\s+/g, " ").trim();
    }
    if (Array.isArray(value.tags) && value.tags.length) {
      return value.tags.join(" · ");
    }
    return "";
  })();
  if (meta) parts.push(meta);
  return parts.join(" · ");
});
</script>

<style scoped>
.work-row {
  display: grid;
  grid-template-columns: 1fr auto;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 10px;
  background: #0d182b;
  border: 1px solid rgba(255, 255, 255, 0.06);
}

.work-left {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 10px;
  align-items: center;
  min-width: 0;
}

.thumb {
  width: 24px;
  height: 24px;
  border-radius: 8px;
  background: rgba(59, 130, 246, 0.14);
  display: grid;
  place-items: center;
  font-size: 15px;
  color: #bfdbfe;
}

.text {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}

.name {
  font-weight: 800;
  font-size: 15px;
  color: #f4f7ff;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.meta-line {
  color: #cbd5e1;
  font-size: 13px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.work-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}

.action {
  height: 30px;
  padding: 0 10px;
  border-radius: 8px;
  border: 1px solid rgba(148, 163, 184, 0.35);
  background: rgba(255, 255, 255, 0.04);
  color: #e5e7eb;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.15s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

.action.primary {
  padding: 0 12px;
}

.action.square {
  width: 34px;
  padding: 0;
}

.action:hover {
  border-color: rgba(59, 130, 246, 0.6);
  box-shadow: 0 6px 16px rgba(59, 130, 246, 0.18);
}

.action:disabled {
  opacity: 0.55;
  cursor: not-allowed;
}

.bolt {
  font-size: 14px;
}

@media (max-width: 960px) {
  .work-row {
    grid-template-columns: 1fr;
    gap: 12px;
  }

  .work-actions {
    justify-content: flex-start;
    flex-wrap: wrap;
  }
}
</style>
