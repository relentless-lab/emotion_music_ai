﻿<template>
  <header class="topbar">
    <div class="top-left">
      <div class="top-title">音乐创作工作台</div>
      <div class="top-subtitle">
        {{ currentNavName }} · 让每一次点击都长出一小段旋律
      </div>
    </div>

    <nav class="top-right">
      <RouterLink to="/notifications" class="pill-btn" title="通知">
        🔔 通知
      </RouterLink>
      <RouterLink to="/account" class="pill-btn" title="账户设置">账户设置</RouterLink>
      <RouterLink v-if="auth.isLoggedIn" to="/profile" class="pill-btn" title="个人资料">
        个人资料
      </RouterLink>
      <button v-else class="pill-btn" type="button" title="登录" @click="ui.openLoginPanel()">
        登录
      </button>
    </nav>
  </header>
</template>

<script setup>
import { computed } from "vue";
import { useRoute, RouterLink } from "vue-router";
import { useAuthStore } from "../stores/auth";
import { useUiStore } from "../stores/ui";

const route = useRoute();
const auth = useAuthStore();
const ui = useUiStore();

const routeNameMap = {
  "/": "首页",
  "/generate": "音乐生成",
  "/emotion": "情绪识别",
  "/works": "我的作品",
  "/history": "历史记录",
  "/notifications": "通知",
  "/settings": "系统设置",
  "/profile": "个人资料",
  "/account": "账户设置"
};

const currentNavName = computed(() => {
  return routeNameMap[route.path] ?? "首页";
});
</script>

<style scoped>
.topbar {
  height: 60px;
  padding: 0 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid rgba(255, 255, 255, 0.03);
  background: linear-gradient(to right, rgba(3, 7, 18, 0.96), rgba(3, 7, 18, 0.9));
  z-index: 2;
}

.top-left {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.top-title {
  font-size: 16px;
  font-weight: 600;
}

.top-subtitle {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.55);
}

.top-right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.pill-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  border-radius: 10px;
  border: 1px solid rgba(148, 163, 184, 0.35);
  background: rgba(15, 23, 42, 0.85);
  color: #e5e7eb;
  font-size: 13px;
  text-decoration: none;
  transition: all 0.16s ease-out;
}

.pill-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 16px rgba(15, 23, 42, 0.45);
  border-color: rgba(59, 130, 246, 0.55);
}
</style>
