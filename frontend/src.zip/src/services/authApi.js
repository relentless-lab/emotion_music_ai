import { api } from "./api";


export function login(payload) {
  return api.post("/api/login", payload);
}



export function register(payload) {
  return api.post("/api/register", payload);
}



export function fetchProfile() {
  return api.get("/api/profile");
}

export function updateProfile(payload) {
  return api.put("/api/profile", payload);
}

export function deleteAccount() {
  return api.delete("/api/account");
}
