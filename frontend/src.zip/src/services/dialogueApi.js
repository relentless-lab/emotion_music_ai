import { api } from "./api";

const mockChatResponse = async payload => {
  return {
    data: {
  "dialogue_id": 1,                     // 对话 ID
  "message_id": 12,                     // 当前消息 ID
  "message": "你好，来一首欢快的电子乐",   // 用户消息
  "reply": "好的，已为你准备一段欢快的电子旋律。", // 系统回复
  "order": 2,                           // 对话轮次
  "title": "生日派对电音",               // 对话标题
  "created_at": "2024-01-01T12:00:00Z", // 创建时间
  "music": {
    "music_id": 1794283019283746512,
    "dialogue_id": 1794283019283746001,
    "file_name": "upbeat_pop_rock.mp3",
    "uml": "/uploads/music/2024/05/20/upbeat_pop_rock.mp3",
    "file_size": 4582912,
    "file_type": "mp3",
    "source_type": "user_upload",
    "duration": 210,
    "is_visible": true,
    "created_at": "2024-05-20T14:30:00Z"
  }
}
  };
};

export const chatWithDialogue = payload => {
    //return mockChatResponse(payload);
  return api.post("/api/dialogues/chat", payload);
};

export const getDialogueDetail = id => {
  return api.get(`/api/dialogues/${id}`);
};
