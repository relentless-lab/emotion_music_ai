import { api } from "./api";

const buildQuery = params => {
  const search = new URLSearchParams(params || {}).toString();
  return search ? `?${search}` : "";
};

const useMock = () => import.meta?.env?.VITE_USE_MOCK === "true";

const sampleHistory = {
  items: [
    {
      id: "h-1001",
      title: "雨夜爵士",
      type: "音乐生成",
      detail: "雨夜街头的慢板爵士，带点复古氛围",
      createdAt: "2024-12-02T12:00:00Z",
      dialogueId: 12,
      order: 3,
      trackUrl: "https://example.com/music/rainy-night-jazz.mp3"
    },
    {
      id: "h-1002",
      title: "霓虹疾驰",
      type: "音乐生成",
      detail: "未来感电音，适合夜跑",
      createdAt: "2024-11-28T09:30:00Z",
      dialogueId: 15,
      order: 1,
      trackUrl: "https://example.com/music/neon-drive.mp3"
    },
    {
      id: "h-1003",
      title: "清晨薄雾",
      type: "情绪识别",
      detail: "美好的感觉，非常放松",
      createdAt: "2024-11-20T17:00:00Z",
      trackUrl: "https://example.com/music/morning-haze.mp3"
    }
  ]
};

export const fetchHistory = async params => {
  if (useMock()) return sampleHistory;
  try {
    return await api.get(`/api/history${buildQuery(params)}`);
  } catch (err) {
    if (err?.status === 404) return { items: [] };
    console.warn("fetchHistory fallback to sample data:", err?.message || err);
    return sampleHistory;
  }
};
