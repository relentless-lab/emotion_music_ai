import { api } from "./api";

// 模拟的分析结果数据
const MOCK_ANALYSIS_RESULT = {
  pieData: {
    joy: 0.35,     // 兴奋
    calm: 0.20,    // 轻松
    rest: 0.15,    // 休闲
    relaxed: 0.10, // 悠闲
    neutral: 0.20  // 平静
  },
  quadrant: {
    x: 0.7, // -1 到 1
    y: 0.6, // -1 到 1
    valence: 78, // 愉悦度 %
    arousal: 79  // 脉动率 %
  },
  waveform: {
    points: [10, 40, 30, 70, 50, 90, 60, 40, 50, 20],
    intensity: 85,
    changeRate: "中等"
  },
  report: "根据上传的音频，系统检测到整体情绪偏向「兴奋 / 快乐」，但伴随轻微的紧张感。节奏起伏平稳，能量集中在中高频段，建议延续当前配乐方向。"
};

/**
 * 上传音频并获取情绪分析结果
 * @param {File} file - 用户上传的音频文件
 * @returns {Promise<Object>} - 分析结果
 */
export async function analyzeAudio(file) {
  // 1. 准备 FormData
  const formData = new FormData();
  formData.append("file", file);

  // TODO: 如果后端接口已就绪，取消下方注释并删除 Mock 逻辑
  /*
  // 调用统一的 api.post，由于传入的是 FormData，api.js 会自动处理 Content-Type
  return api.post("/api/emotion/analyze", formData);
  */

  // Mock 延迟模拟网络请求
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(MOCK_ANALYSIS_RESULT);
    }, 2000);
  });
}