import { api } from "./api";

const buildQuery = params => {
  const search = new URLSearchParams(params || {}).toString();
  return search ? `?${search}` : "";
};

const useMock = () => import.meta?.env?.VITE_USE_MOCK === "true";

const sampleWorks = [
  {
    id: 101,
    userId: 1,
    name: "雨夜爵士",
    icon: "sax",
    meta: "lofi · jazz · 02:34",
    tags: ["lofi", "jazz", "midnight"],
    url: "https://example.com/music/rainy-night-jazz.mp3",
    createdAt: "2024-12-02T12:00:00Z"
  },
  {
    id: 102,
    userId: 1,
    name: "霓虹疾驰",
    icon: "synth",
    meta: "synthwave · 03:12",
    tags: ["synthwave", "edm"],
    url: "https://example.com/music/neon-drive.mp3",
    createdAt: "2024-11-28T09:30:00Z"
  },
  {
    id: 103,
    userId: 1,
    name: "清晨薄雾",
    icon: "mist",
    meta: "ambient · 04:05",
    tags: ["ambient", "calm"],
    url: "https://example.com/music/morning-haze.mp3",
    createdAt: "2024-11-20T16:45:00Z"
  }
];

export const fetchWorks = async params => {
  if (useMock()) return sampleWorks;
  try {
    return await api.get(`/api/works${buildQuery(params)}`);
  } catch (err) {
    if (err?.status === 404) return [];
    console.warn("fetchWorks fallback to sample data:", err?.message || err);
    return sampleWorks;
  }
};

export const createWork = payload => api.post("/api/works", payload);

export const updateWork = (id, payload) => api.put(`/api/works/${id}`, payload);

export const deleteWork = id => api.delete(`/api/works/${id}`);
